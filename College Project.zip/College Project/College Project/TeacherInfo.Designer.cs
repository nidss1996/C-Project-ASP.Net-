﻿namespace College_Project
{
    partial class TeacherInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TeacherInfo));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtTname = new System.Windows.Forms.TextBox();
            this.txttmob = new System.Windows.Forms.TextBox();
            this.txttemail = new System.Windows.Forms.TextBox();
            this.radiobtnmale = new System.Windows.Forms.RadioButton();
            this.radiobtnfemale = new System.Windows.Forms.RadioButton();
            this.comboBoxtsem = new System.Windows.Forms.ComboBox();
            this.comboBoxtprog = new System.Windows.Forms.ComboBox();
            this.comboBoxtduration = new System.Windows.Forms.ComboBox();
            this.richTextBoxtadd = new System.Windows.Forms.RichTextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.dateTimePickert = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(234, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(72, 61);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(349, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(164, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "Basic Information ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(55, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 22);
            this.label2.TabIndex = 2;
            this.label2.Text = "Full Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(75, 186);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 22);
            this.label3.TabIndex = 3;
            this.label3.Text = "Gender";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(78, 225);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 16);
            this.label4.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(46, 266);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 22);
            this.label5.TabIndex = 5;
            this.label5.Text = "Mobile No.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(55, 308);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 22);
            this.label6.TabIndex = 6;
            this.label6.Text = "Email ID";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(450, 280);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 22);
            this.label7.TabIndex = 7;
            this.label7.Text = "Address";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(450, 234);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 22);
            this.label8.TabIndex = 8;
            this.label8.Text = "Duration";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(450, 188);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(113, 22);
            this.label9.TabIndex = 9;
            this.label9.Text = "Programming";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(450, 150);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(80, 22);
            this.label10.TabIndex = 10;
            this.label10.Text = "Semester";
            // 
            // txtTname
            // 
            this.txtTname.Location = new System.Drawing.Point(177, 142);
            this.txtTname.Name = "txtTname";
            this.txtTname.Size = new System.Drawing.Size(118, 22);
            this.txtTname.TabIndex = 11;
            // 
            // txttmob
            // 
            this.txttmob.Location = new System.Drawing.Point(177, 267);
            this.txttmob.Name = "txttmob";
            this.txttmob.Size = new System.Drawing.Size(129, 22);
            this.txttmob.TabIndex = 12;
            // 
            // txttemail
            // 
            this.txttemail.Location = new System.Drawing.Point(177, 309);
            this.txttemail.Name = "txttemail";
            this.txttemail.Size = new System.Drawing.Size(177, 22);
            this.txttemail.TabIndex = 13;
            // 
            // radiobtnmale
            // 
            this.radiobtnmale.AutoSize = true;
            this.radiobtnmale.Location = new System.Drawing.Point(164, 186);
            this.radiobtnmale.Name = "radiobtnmale";
            this.radiobtnmale.Size = new System.Drawing.Size(58, 20);
            this.radiobtnmale.TabIndex = 14;
            this.radiobtnmale.TabStop = true;
            this.radiobtnmale.Text = "Male";
            this.radiobtnmale.UseVisualStyleBackColor = true;
            // 
            // radiobtnfemale
            // 
            this.radiobtnfemale.AutoSize = true;
            this.radiobtnfemale.Location = new System.Drawing.Point(232, 186);
            this.radiobtnfemale.Name = "radiobtnfemale";
            this.radiobtnfemale.Size = new System.Drawing.Size(74, 20);
            this.radiobtnfemale.TabIndex = 15;
            this.radiobtnfemale.TabStop = true;
            this.radiobtnfemale.Text = "Female";
            this.radiobtnfemale.UseVisualStyleBackColor = true;
            // 
            // comboBoxtsem
            // 
            this.comboBoxtsem.FormattingEnabled = true;
            this.comboBoxtsem.Items.AddRange(new object[] {
            "1st Sem",
            "2nd Sem",
            "3rd Sem ",
            "4th Sem ",
            "5th Sem ",
            "6th Sem ",
            "7th Sem ",
            "8th Sem "});
            this.comboBoxtsem.Location = new System.Drawing.Point(569, 150);
            this.comboBoxtsem.Name = "comboBoxtsem";
            this.comboBoxtsem.Size = new System.Drawing.Size(121, 24);
            this.comboBoxtsem.TabIndex = 16;
            // 
            // comboBoxtprog
            // 
            this.comboBoxtprog.FormattingEnabled = true;
            this.comboBoxtprog.Items.AddRange(new object[] {
            "C",
            "C++ ",
            "C# ",
            "Go Lang",
            "JAVA ",
            "JavaScript",
            "NodeJs ",
            "ReactJs ",
            "AngularJs"});
            this.comboBoxtprog.Location = new System.Drawing.Point(569, 186);
            this.comboBoxtprog.Name = "comboBoxtprog";
            this.comboBoxtprog.Size = new System.Drawing.Size(121, 24);
            this.comboBoxtprog.TabIndex = 17;
            // 
            // comboBoxtduration
            // 
            this.comboBoxtduration.FormattingEnabled = true;
            this.comboBoxtduration.Items.AddRange(new object[] {
            "2016-2020",
            "2010-2014",
            "2014-2016",
            "2016-2020"});
            this.comboBoxtduration.Location = new System.Drawing.Point(569, 234);
            this.comboBoxtduration.Name = "comboBoxtduration";
            this.comboBoxtduration.Size = new System.Drawing.Size(121, 24);
            this.comboBoxtduration.TabIndex = 18;
            // 
            // richTextBoxtadd
            // 
            this.richTextBoxtadd.Location = new System.Drawing.Point(569, 280);
            this.richTextBoxtadd.Name = "richTextBoxtadd";
            this.richTextBoxtadd.Size = new System.Drawing.Size(169, 78);
            this.richTextBoxtadd.TabIndex = 19;
            this.richTextBoxtadd.Text = "";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(339, 380);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 30);
            this.button1.TabIndex = 20;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Calibri", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(41, 219);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(107, 22);
            this.label11.TabIndex = 21;
            this.label11.Text = "Date Of Birth";
            // 
            // dateTimePickert
            // 
            this.dateTimePickert.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickert.Location = new System.Drawing.Point(177, 225);
            this.dateTimePickert.Name = "dateTimePickert";
            this.dateTimePickert.Size = new System.Drawing.Size(129, 22);
            this.dateTimePickert.TabIndex = 22;
            // 
            // TeacherInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dateTimePickert);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.richTextBoxtadd);
            this.Controls.Add(this.comboBoxtduration);
            this.Controls.Add(this.comboBoxtprog);
            this.Controls.Add(this.comboBoxtsem);
            this.Controls.Add(this.radiobtnfemale);
            this.Controls.Add(this.radiobtnmale);
            this.Controls.Add(this.txttemail);
            this.Controls.Add(this.txttmob);
            this.Controls.Add(this.txtTname);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "TeacherInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Full Name";
            this.Load += new System.EventHandler(this.TeacherInfo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtTname;
        private System.Windows.Forms.TextBox txttmob;
        private System.Windows.Forms.TextBox txttemail;
        private System.Windows.Forms.RadioButton radiobtnmale;
        private System.Windows.Forms.RadioButton radiobtnfemale;
        private System.Windows.Forms.ComboBox comboBoxtsem;
        private System.Windows.Forms.ComboBox comboBoxtprog;
        private System.Windows.Forms.ComboBox comboBoxtduration;
        private System.Windows.Forms.RichTextBox richTextBoxtadd;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dateTimePickert;
    }
}