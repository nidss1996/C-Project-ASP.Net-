﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Xml.Linq;
using System.Data.Common;

namespace College_Project
{
    public partial class SearchStudent : Form
    {
        public SearchStudent()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Int32 regId =Convert.ToInt32( txtsearch.Text);
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source = LAPTOP-D6U47JQP\\SQLEXPRESS; database= CollegeSystem; integrated security = True ";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "select * from NewAdmission where NAID = "+regId+" ";
            SqlDataAdapter DA = new SqlDataAdapter(cmd); // read the data from database and bind the data to dataset(collection of datatable)
            DataSet DS = new DataSet();
            DA.Fill(DS);
            con.Close();
            dataGridView1.DataSource = DS.Tables[0];

        }

        private void SearchStudent_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source = LAPTOP-D6U47JQP\\SQLEXPRESS; database= CollegeSystem; integrated security = True ";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "select NewAdmission.NAID as studentId, NewAdmission.fname as FullName, NewAdmission.mname as Mother_name, NewAdmission.dob as Date_of_birth,NewAdmission.gender as gender, NewAdmission.mobile as Mobile_No, NewAdmission.email as Email, NewAdmission.semester as Semester, NewAdmission.prog as Programming, NewAdmission.sname as School_Name, NewAdmission.duration as Duration, NewAdmission.addres as adress, Fees.fee as Fees from NewAdmission inner join Fees on NewAdmission.NAID = Fees.NAID ";
            SqlDataAdapter DA = new SqlDataAdapter(cmd); // read the data from database and bind the data to dataset(collection of datatable)
            DataSet DS = new DataSet();
            DA.Fill(DS);
            con.Close();
            dataGridView1.DataSource = DS.Tables[0];
            
        }
    }
}
