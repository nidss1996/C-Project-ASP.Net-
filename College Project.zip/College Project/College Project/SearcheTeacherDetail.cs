﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace College_Project
{
    public partial class SearcheTeacherDetail : Form
    {
        public SearcheTeacherDetail()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Int32 regId = Convert.ToInt32(txtsearch.Text);
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source = LAPTOP-D6U47JQP\\SQLEXPRESS; database= CollegeSystem; integrated security = True ";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "select * from TeacherInfo where tID = " + regId + " ";
            SqlDataAdapter DA = new SqlDataAdapter(cmd); // read the data from database and bind the data to dataset(collection of datatable)
            DataSet DS = new DataSet();
            DA.Fill(DS);
            con.Close();
            dataGridView1.DataSource = DS.Tables[0];
        }

        private void SearcheTeacherDetail_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source = LAPTOP-D6U47JQP\\SQLEXPRESS; database= CollegeSystem; integrated security = True ";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "select TeacherInfo.tID as teacherId, TeacherInfo.fname as FullName, TeacherInfo.gender as gender, TeacherInfo.dob as Date_of_birth, TeacherInfo.mobile as Mobile_No, TeacherInfo.email as Email, TeacherInfo.sem as Semester, TeacherInfo.prog as Programming,TeacherInfo.duration as Duration, TeacherInfo.adress as adress from TeacherInfo";
            SqlDataAdapter DA = new SqlDataAdapter(cmd); //
            DataSet DS = new DataSet();
            DA.Fill(DS);
            con.Close();
            dataGridView1.DataSource = DS.Tables[0];
        }
    }
}
