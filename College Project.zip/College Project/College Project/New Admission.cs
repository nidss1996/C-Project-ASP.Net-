﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Xml.Linq;

namespace College_Project
{
    public partial class New_Admission : Form
    {
        public New_Admission()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void New_Admission_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source = LAPTOP-D6U47JQP\\SQLEXPRESS; database= CollegeSystem; integrated security = True ";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "Select MAX(NAID) from NewAdmission";
            SqlDataAdapter DA = new SqlDataAdapter(cmd); // read the data from database and bind the data to dataset(collection of datatable)
            DataSet DS = new DataSet();
            DA.Fill(DS);
            con.Close();
            Int64 registID = Convert.ToInt64(DS.Tables[0].Rows[0][0]);
            label1.Text = (registID+1).ToString();
        }
        private void label3_Click(object sender, EventArgs e)
        {
        }
        private void label4_Click(object sender, EventArgs e)
        {
        }
        private void label5_Click(object sender, EventArgs e)
        {
        }
        private void label7_Click(object sender, EventArgs e)
        {
        }
        private void label2_Click(object sender, EventArgs e)
        {
        }
        private void label8_Click(object sender, EventArgs e)
        {
        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string fname = txtFullName.Text;
            string mname = txtMotherName.Text;
            string gender = "";
            bool isChecked = btnMale.Checked;
            if (isChecked)
            {
                gender = btnMale.Text;
            }
            else
            {
                gender = btnFemale.Text;
            }

            string dob = dateTimePicker1.Text;
            Int64 mobile = Int64.Parse(txtMobileNo.Text);
            string email = txtEmailId.Text;
            string sem = comboBoxSem.Text;
            string prog = comboBoxPro.Text;
            string sname = txtSchoolName.Text;
            string duration = comboBoxDuration.Text;
            string addres = richTextBox1.Text;

            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source = LAPTOP-D6U47JQP\\SQLEXPRESS; database= CollegeSystem; integrated security = True ";

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "insert into NewAdmission ( fname , mname , gender , dob , mobile , email , semester , prog , sname , duration , addres) values('" + fname + "', '" + mname + "', '" + gender + "', '" + dob + "', " + mobile + ",'" + email + "', '" + sem + "', '" + prog + "', '" + sname + "','" + duration + "','" + addres + "')";
            SqlDataAdapter DA = new SqlDataAdapter(cmd); // read the data from database and bind the data to dataset(collection of datatable)
            DataSet DS = new DataSet();
            DA.Fill(DS);
            con.Close();

            MessageBox.Show("data saved, remember registration No ", " data ", MessageBoxButtons.OK, MessageBoxIcon.Hand);



        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtEmailId.Clear();
            txtFullName.Clear();
            txtMobileNo.Clear();
            txtMotherName.Clear();
            txtSchoolName.Clear();
            btnMale.Checked= false;
           btnFemale.Checked= false;
            comboBoxSem.ResetText();
            comboBoxPro.ResetText();
           comboBoxDuration.ResetText();
            richTextBox1.Clear();   

        }
    }
}
