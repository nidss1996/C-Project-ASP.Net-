﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace College_Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void searcheToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearcheTeacherDetail objNew = new SearcheTeacherDetail();
           objNew.Show();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            menuStrip1.Visible = false;
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string userName = textBox1.Text;
            string Passsword = textBox2.Text;
            if (userName == "Nidhi" && Passsword == "Nidhi@123")
            {
                menuStrip1.Visible = true;
                panel1.Visible = false;
            }
            else
            {
                panel1.Visible=true;
                MessageBox.Show("Invalid userName or Password","Error",MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void newAdmissionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            New_Admission objNew = new New_Admission();
            objNew.Show();
        }

        private void upgradeSemesterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpgradeSem objNew = new UpgradeSem();
            objNew.Show();
        }

        private void feesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Fees objNew = new Fees();
            objNew.Show();
        }

        private void newStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchStudent objNew = new SearchStudent();
            objNew.Show();
        }

        private void individualDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IndividualDetail objNew = new IndividualDetail();
            objNew.Show();
        }

        private void addTeacherInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TeacherInfo objNew = new TeacherInfo();
            objNew.Show();
        }

        private void aboutUsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutUs objNew = new AboutUs();
            objNew.Show();
        }

        private void exitSystemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are you sure, this will delete unsaved data", "Confirmation Dialouge ", MessageBoxButtons.OKCancel,MessageBoxIcon.Warning) == DialogResult.OK)
            {
                Application.Exit();
            }
        }
    }
}
