﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace College_Project
{
    public partial class UpgradeSem : Form
    {
        public UpgradeSem()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string fromsem = comboBoxFrom.Text;
            string tosem = comboBoxTo.Text;
            if(MessageBox.Show("semester upgrade warning ! ","Confirm ",MessageBoxButtons.OKCancel) == DialogResult.OK) 
            {
                if (fromsem != tosem)
                {
                    SqlConnection con = new SqlConnection();
                    con.ConnectionString = "data source = LAPTOP-D6U47JQP\\SQLEXPRESS; database= CollegeSystem; integrated security = True ";
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = "update NewAdmission set semester = '" + tosem + "' where semester = '" + fromsem + "' ;";
                    SqlDataAdapter DA = new SqlDataAdapter(cmd); // read the data from database and bind the data to dataset(collection of datatable)
                    DataSet DS = new DataSet();
                    DA.Fill(DS);
                    con.Close();

                    MessageBox.Show("Upgraded, Semester is upto date", " Upgradation  ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("upgrade cancel", " cancellation   ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
        }
    }
}
