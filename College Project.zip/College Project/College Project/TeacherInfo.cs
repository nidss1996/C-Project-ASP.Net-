﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Xml.Linq;

namespace College_Project
{
    public partial class TeacherInfo : Form
    {
        public TeacherInfo()
        {
            InitializeComponent();
        }

        private void TeacherInfo_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string tName = txtTname.Text; ;
            string tgender = "";
            bool isChecked = radiobtnmale.Checked;
            if (isChecked)
            {
                tgender = radiobtnmale.Text;
            }
            else
            {
                tgender = radiobtnmale.Text;
            }
            string tdob = dateTimePickert.Text;
            Int64 tmobile= Convert.ToInt64(txttmob.Text);
            string temail = txttemail.Text;
            string tsem = comboBoxtsem.Text;
            string tprog = comboBoxtprog.Text;
            string tdurartion = comboBoxtduration.Text;
            string tadress = richTextBoxtadd.Text;

            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source = LAPTOP-D6U47JQP\\SQLEXPRESS; database= CollegeSystem; integrated security = True ";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "insert into TeacherInfo ( fname ,gender , dob , mobile , email , sem , prog , duration , adress) values('" + tName + "', '" + tgender + "', '" + tdob + "', " + tmobile + ", '" + temail + "','" + tsem + "', '" + tprog + "', '" + tdurartion + "', '" + tadress + "')";
            SqlDataAdapter DA = new SqlDataAdapter(cmd); // read the data from database and bind the data to dataset(collection of datatable)
            DataSet DS = new DataSet();
            DA.Fill(DS);
            con.Close();
           if(MessageBox.Show("Teacher information is saved ", "  Teacher Info ", MessageBoxButtons.OK, MessageBoxIcon.Hand)== DialogResult.OK);
            {
                txtTname.Clear();
                txttmob.Clear();
                txttemail.Clear();
                comboBoxtsem.ResetText();
                comboBoxtprog.ResetText();
                comboBoxtduration.ResetText();
                richTextBoxtadd.Clear();
                radiobtnmale.Checked = false;
                radiobtnfemale.Checked = false;
            }

           

        }
    }
}
