﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Xml.Linq;

namespace College_Project
{
    public partial class Fees : Form
    {
        public Fees()
        {
            InitializeComponent();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnfeesSubmit_Click(object sender, EventArgs e)
        {
            Int32 regisNo = Convert.ToInt32(txtResNo.Text);
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source = LAPTOP-D6U47JQP\\SQLEXPRESS; database= CollegeSystem; integrated security = True ";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "select * from Fees where NAID = " + regisNo + "";
            SqlDataAdapter DA = new SqlDataAdapter(cmd); // read the data from database and bind the data to dataset(collection of datatable)
            DataSet DS = new DataSet(); // temproray collection of datatable
            DA.Fill(DS); // pooja ankita 2002-2008
            con.Close(); 

            if (DS.Tables[0].Rows.Count == 0)
            {
               SqlConnection con1 = new SqlConnection();
                con1.ConnectionString = "data source = LAPTOP-D6U47JQP\\SQLEXPRESS; database= CollegeSystem; integrated security = True ";
                SqlCommand cmd1 = new SqlCommand();
                cmd1.Connection = con1;
                cmd1.CommandText = " insert into Fees (NAID, fee) values('" + txtResNo.Text + "','" + txtFees.Text + "')";
                SqlDataAdapter DA1 = new SqlDataAdapter(cmd1); // read the data from database and bind the data to dataset(collection of datatable)
                DataSet DS1 = new DataSet(); // temproray collection of datatable
                DA1.Fill(DS1); // pooja ankita 2002-2008
                con1.Close();
                if (MessageBox.Show("fee submitted  ! ", "Information ", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    txtResNo.Clear();
                    txtFees.Clear();
                    fname.Text = "-------";
                    mname.Text = "-------";
                    Duration.Text = "-------";
                }
            }
            else
            {
                MessageBox.Show("Duplicate Registration No  ! ", "Warning ", MessageBoxButtons.OKCancel, MessageBoxIcon.Error);

            }







            

        }

        private void txtResNo_TextChanged(object sender, EventArgs e)
        {
            if(txtResNo.Text != "")
            {
                Int32 resgNo = Convert.ToInt32(txtResNo.Text);
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "data source = LAPTOP-D6U47JQP\\SQLEXPRESS; database= CollegeSystem; integrated security = True ";
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "select fname, mname, duration from NewAdmission where NAID = " + resgNo + "";
                SqlDataAdapter DA = new SqlDataAdapter(cmd); // read the data from database and bind the data to dataset(collection of datatable)
                DataSet DS = new DataSet(); // temproray collection of datatable
                DA.Fill(DS); // pooja ankita 2002-2008
                con.Close();
                if (DS.Tables[0].Rows.Count > 0)
                {
                    fname.Text = (string)DS.Tables[0].Rows[0][0];
                    mname.Text = (string)DS.Tables[0].Rows[0][1];
                    Duration.Text = (string)DS.Tables[0].Rows[0][2];
                }
                else
                {
                    fname.Text = "-------";
                    mname.Text = "-------";
                    Duration.Text = "-------";

                }



            }
            else
            {
                fname.Text = "-------";
                mname.Text = "-------";
                Duration.Text = "-------";

            }



        }
    }
}
