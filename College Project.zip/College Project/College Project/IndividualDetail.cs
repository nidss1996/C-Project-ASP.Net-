﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace College_Project
{
    public partial class IndividualDetail : Form
    {
        public IndividualDetail()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtRegNo.Clear();
            txtname.Clear();
            txtmname.Clear();
            txtGen.Clear();
            txtMob.Clear();
            txtEmail.Clear();
            txtStant.Clear();
            txtMedium.Clear();
            txtschoolName.Clear();
            txtyear.Clear();
            txtyear.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Int32 regId = Convert.ToInt32(txtRegNo.Text);
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source = LAPTOP-D6U47JQP\\SQLEXPRESS; database= CollegeSystem; integrated security = True ";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "select * from NewAdmission where NAID = " + regId + " ";
            SqlDataAdapter DA = new SqlDataAdapter(cmd); // read the data from database and bind the data to dataset(collection of datatable)
            DataSet DS = new DataSet();
            DA.Fill(DS);
            con.Close();
            if (DS.Tables[0].Rows.Count > 0)
            {
                txtname.Text = (string)DS.Tables[0].Rows[0][1];
                txtmname.Text = (string)DS.Tables[0].Rows[0][2];
                txtGen.Text = (string)DS.Tables[0].Rows[0][3];
                txtDOB.Text= DS.Tables[0].Rows[0][4].ToString();
                txtMob.Text = DS.Tables[0].Rows[0][5].ToString();
                txtEmail.Text = (string)DS.Tables[0].Rows[0][6];
                txtStant.Text = (string)DS.Tables[0].Rows[0][7];
                txtMedium.Text = (string)DS.Tables[0].Rows[0][8];
                txtschoolName.Text = (string)DS.Tables[0].Rows[0][9];
                txtyear.Text = (string)DS.Tables[0].Rows[0][10];
                txtAddress.Text = (string)DS.Tables[0].Rows[0][11];


            }
            else
            {
                MessageBox.Show("Wrong Registration ID", "Information", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
            }
        }
    }
}
